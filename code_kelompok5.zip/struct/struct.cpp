#include "struct.h"

Matkul daftarMatkul[MAX];
Mhs    daftarMhs[MAX];
Dosen  daftarDosen[MAX];
Akun   daftarAkun[MAX];

int jumlahAkun = 0, jumlahMhs = 0, jumlahDosen = 0, jumlahMatkul = 0;